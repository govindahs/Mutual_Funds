﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLib
{
   
    public interface IDalComponent
    {
        void AddFund(MutualFund mfund);
        void UpdateFund(MutualFund mfund);
        void DeleteFund(int id);
        List<MutualFund> DisplayAllFunds();
        List<UserTable> DisplayAllUsers();
        List<MutualFund> SortByCategory(int id);

    }
    public static class MutualFundDBFactory
    {
        public static IDalComponent GetComponent() => new DalComponent();
    }

    public class DalComponent : IDalComponent
    {
        ProjectDBEntities db=new ProjectDBEntities();
        public void AddFund(MutualFund mfund)
        {
            db.MutualFunds.Add(mfund);
            db.SaveChanges();  
        }


        public void addpayment(tblMoney tbl)
        {
            db.tblMoneys.Add(tbl);
            db.SaveChanges();
        }
        public void adduserlintable(tblUserLink userLink)
        {
            db.tblUserLinks.Add(userLink);
            db.SaveChanges();
        }
       public void Addforidintable(IdForTable id)
        {
            db.IdForTables.Add(id);
            db.SaveChanges();
        }
        public void addforuserlintable(tblUserLink userLink)
        {
            db.tblUserLinks.Add(userLink);
            db.SaveChanges();
        }
        public void DeleteFund(int id)
        {
            var res = db.MutualFunds.FirstOrDefault((e) => e.MFId == id);
            if (res == null) throw new Exception($"MutualFund with ID{id} not found to delete");
            db.MutualFunds.Remove(res);
            db.SaveChanges();
        }


        public void DeleteUsertable(int id)
        {
            var res = db.tblUserLinks.FirstOrDefault((e) => e.LinkId == id);
            db.tblUserLinks.Remove(res);
            db.SaveChanges();
        }

        public List<MutualFund> DisplayAllFunds()
        {
            var mfund = db.MutualFunds.ToList();
            return mfund;
        }


        public List<UserTable> DisplayAllUsers()
        {
            var data1 = db.UserTables.ToList();
            return data1;
        }

        public List<tblMoney> Displya(int id)
        {
            var res = db.tblMoneys.Where(e => e.UserId == id);
            return res.ToList();
        }
       public List<tblUserLink> Displayname(int id)
        {
            var res1 = db.tblUserLinks.Where(e => e.UserId == id);
            return res1.ToList();
        }

        public object DisplayDetailsById(int? idies)
        {
            throw new NotImplementedException();
        }

        public List<MutualFund> SortByCategory(int id)
        { 
            var model = db.MutualFunds.Where(x => x.CategoryId== id);
            return model.ToList();
        }




        public void UpdateFund(MutualFund mfund)
        {
           
            var res = db.MutualFunds.FirstOrDefault((e) => e.MFId == mfund.MFId);
            res.FundName = mfund.FundName;
            res.NAV= mfund.NAV;
            res.BenchMark = mfund.BenchMark;
            res.Risk = mfund.Risk;
            res.Goal = mfund.Goal;
            res.FundManager = mfund.FundManager;
            res.LockIn = mfund.LockIn;
            res.ExpenseRatio = mfund.ExpenseRatio;
            res.FundOwner = mfund.FundOwner;
            res.Rating = mfund.Rating;
            res.CategoryId = mfund.CategoryId;
            db.SaveChanges();

        }

        public void UpdateMoneyTable(tblMoney tbl)
        {
            var res = db.tblMoneys.FirstOrDefault((e) => e.PaymentId == tbl.PaymentId);
            res.Amount += tbl.Amount;
            res.UserId = tbl.UserId;
            res.MFId = tbl.MFId;
            db.SaveChanges();
        }
        public void RedeemUpdateMoneyTable(tblMoney tbl)
        {
            var res = db.tblMoneys.FirstOrDefault((e) => e.PaymentId == tbl.PaymentId);
            res.Amount -= tbl.Amount;
            res.UserId = tbl.UserId;
            res.MFId = tbl.MFId;
            db.SaveChanges();
        }


        public void UpdateUserlinTable(tblUserLink userLink)
        {
            var res = db.tblUserLinks.FirstOrDefault((e) => e.LinkId == userLink.LinkId);
            res.MFId = userLink.MFId;
            res.NAVOnDate = userLink.NAVOnDate;
            res.PaymentId = userLink.PaymentId;
            res.Units = userLink.Units;
            res.UserId = userLink.UserId;
            res.Date = userLink.Date;
            db.SaveChanges();
        }



        public MutualFund DisplayById(int id)
        {
            var res = db.MutualFunds.FirstOrDefault((e) => e.MFId == id);
            return res;
        }
        
        public tblUserLink displaybyLinkId(int id)
        {
            var res = db.tblUserLinks.FirstOrDefault((e) => e.LinkId == id);
            return res;
        }
       public tblMoney SearchdatabyPaymentId(int id)
        {
            var res = db.tblMoneys.FirstOrDefault((e) => e.PaymentId == id);
            return res;
        }

    
        public UserTable DisplayDetailsById(int id) //this function uses for getting details for User Profile
        {
            var res2 = db.UserTables.FirstOrDefault((e) => e.UserId == id);
            return res2;
        }

        public int NeedID(string name,string pass)
        {
            //var id = db.UserTables.Any((e) => e.EmailId==name && e.Password==pass);
            //return id
            int userId = db.UserTables.Where(m => m.EmailId ==name && m.Password==pass).Select(m => m.UserId).SingleOrDefault();
            return userId;

        }

    }
}
