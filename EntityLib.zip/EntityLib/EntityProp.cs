﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLib
{
    public class MutualFundEntity
    {
        public int MFId { get; set; }
        public string FundName { get; set; }
        public double NAV { get; set; }
        public string BenchMark { get; set; }
        public string Risk { get; set; }
        public string Goal { get; set; }
        public string FundManager { get; set; }
        public string LockIn { get; set; }
        public double ExpenseRatio { get; set; }
        public string FundOwner { get; set; }
        public double Rating { get; set; }
        public int CategoryId { get; set; }


    }


    public class LoginTable
    {   
        public string Username { get; set; }
        public string password { get; set; }
    }

    public class tblAmounttable
    {
        public int Amountdata { get; set; }

    }


}
